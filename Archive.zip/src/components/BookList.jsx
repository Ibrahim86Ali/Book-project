
import Card from "react-bootstrap/Card";
import Row from 'react-bootstrap/Row';
import useFetch from "../useFetch";
import { Link } from "react-router-dom/cjs/react-router-dom";
import { useState} from "react";
export const BookList =()=>{
 
  const [bookList,setBookList]=useState([])   

//   const bookListHandler=(id)=>{
//     setBookList([…bookList, id]);
// };
// console.log(setBookList)


  
    const {setReady,data}=useFetch()

 return(
   <>
   
{setReady && data.map((item) =>(
   
  <div key={item.id} className=" d-inline-flex p-2 bg-dark ">
  
  <Row  > 
     <Card  className="  bg-dark border border-warning rounded "  style={{paddingLeft:"3em",height:"20em",width: "14em" }}>
      <Card.Img  className=" align-self-baseline" style={{ paddingTop:20,height:"14em", width: "9em" }} src={item.formats["image/jpeg"]} /><Card.Body>
    
  
     
        {<a href={item.formats["text/html"]} style={{padding:"0.50vw",textAlign:"center" }} target="/favlist"  rel="noreferrer" className=" bg-dark btn btn-outline-warning btn-sm "> Preview
        </a> }
        <button onClick={()=>{console.log(item.id)
        bookListHandler(item.id)} } type="button" className=" bg-dark btn btn-outline-warning btn-sm "> + to Read list</button>
         </Card.Body>
      </Card>
    </Row>
     </div>))};
    </>
     )}
     
    
    export default BookList
