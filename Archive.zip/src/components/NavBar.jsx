import Container from 'react-bootstrap/Container';
import { useState } from 'react';
import { Link } from 'react-router-dom';


export const NavBar=()=>{
   
return(
<Container>

    <Link  to="/Booklist" type="button"  className=" bg-dark btn btn-outline-warning btn-sm ">Books List</Link>
    <Link  to="/FavList" type="button"  className=" bg-dark btn btn-outline-warning btn-sm ">Favorit list</Link>    

    </Container>)


}
