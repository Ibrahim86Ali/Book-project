import { useState } from "react";

export const FavList = () => {
 
   
  return (
    <div className="mh-vh-100 ">
   
      <h1>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis eius
        perferendis nostrum voluptatum quisquam totam dignissimos beatae in
        aliquam, ducimus amet dolor vero sapiente cum inventore voluptatem
        harum, cumque odit.
      </h1>
    </div>
  );
};
