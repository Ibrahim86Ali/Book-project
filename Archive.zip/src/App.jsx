import { BrowserRouter as Router,Route,Switch } from 'react-router-dom/cjs/react-router-dom.min';
import {BookList} from'./components/BookList'
import { NavBar } from './components/NavBar';
import {FavList } from './components/FavList';

function App() {
  return(
    <Router>
<NavBar/>
<Switch>
  <Route  exact path="/Booklist" >
<BookList/>
</Route>
<Route exact path="/FavList" >
<FavList/>
</Route>
</Switch>
  </Router>

  
  )
  
}

export default App;
